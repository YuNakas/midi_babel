"""
Include YAML files within YAML
"""

from .constructor import *
from .readers import *
from .version import __version__, __version_tuple__
